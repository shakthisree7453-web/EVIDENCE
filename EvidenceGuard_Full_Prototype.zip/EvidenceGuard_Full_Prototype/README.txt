EvidenceGuard Full Prototype

1. Make a backup of your existing EvidenceGuard folder and database.json first.
2. Copy backend/server.js and frontend files into your existing project, or test this folder as a separate copy. Keep your old backend/uploads folder and existing database.json if you need old documents.
3. Open terminal in this project folder. Run: npm install
4. Start: npm.cmd start (PowerShell may block npm.ps1)
5. Open http://localhost:3000

Demo accounts:
Higher Official: POL1001 / admin123
Investigation Officer: POL1002 / officer123

Features: login token, role-filtered documents, upload, SHA-256, document view, version history, Higher Official modification, audit trail, weekly report, local hash-linked ledger, integrity verification, logout.

IMPORTANT: Prototype only. Token secret and demo passwords are not production-secure. Do not use real sensitive/legal records. The ledger is a local SHA-256 hash chain, not Hyperledger Fabric.

Existing database migration: if using your own database/database.json, keep a backup. This code keeps existing document/version/audit/ledger arrays; missing arrays are initialized. Older records whose actual files are absent from backend/uploads cannot be opened or integrity-checked until those files are restored.
